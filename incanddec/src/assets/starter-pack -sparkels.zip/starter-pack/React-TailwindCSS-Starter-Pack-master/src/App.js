import React from 'react';
import './App.css';

function App() {
  return (
    <h1 className="h-screen text-3xl text-center font-bold flex justify-center items-center underline">
      React + TailwindCSS
    </h1>
  )
}

export default App;
