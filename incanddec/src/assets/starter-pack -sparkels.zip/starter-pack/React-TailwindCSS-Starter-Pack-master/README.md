# React-TailWindCSS-Starter-Pack

**Step 1:** Download this repo as a zip

**Step 2:** To run:

```bash
npm install
npm start
```

**Step 3:** Go to [http://localhost:3000](http://localhost:3000)

Facing any issue: [Documentation](https://tailwindcss.com/docs/guides/create-react-app)